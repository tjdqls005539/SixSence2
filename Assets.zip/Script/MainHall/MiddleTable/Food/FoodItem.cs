using UnityEngine;

public class FoodItem : MonoBehaviour
{
    public Food foodData;
}


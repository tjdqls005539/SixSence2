public enum FoodType
{
    ChocolateCake,
    Soup,
    Steak,
    Pasta,
    OmeletRice,
    Pudding
}

